import React from 'react';
import '../Style.css';

const Wallet = () => {
	return (
		<>
			<div style={{}} className='submission-header'>
				<h2>Wallet</h2>
				
            </div>
            <hr />
            <div className='submission-body'>
                <p>Your Wallet Will Appeare Here!</p>
            </div>
		</>
	);
};

export default Wallet;
