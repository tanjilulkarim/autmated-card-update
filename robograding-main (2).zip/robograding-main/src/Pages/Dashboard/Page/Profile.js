import React from 'react';
import '../Style.css';

const Profile = () => {
	return (
		<>
			<div style={{}} className='submission-header'>
				<h2>Profile</h2>
				
            </div>
            <hr />
            <div className='submission-body'>
                <p>Hello, Sulaiman Hosain</p>
            </div>
		</>
	);
};

export default Profile;
