import { Typography } from '@mui/material';
import React from 'react';

const SignIn = () => {
    return (
        <div style={{width:'60%'}}>
            <Typography variant='h4'>Sign Up to AGS to Access Robograding</Typography>
        </div>
    );
};

export default SignIn;